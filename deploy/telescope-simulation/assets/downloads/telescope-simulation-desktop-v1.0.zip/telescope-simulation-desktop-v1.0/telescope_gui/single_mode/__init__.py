"""Single telescope mode tabs."""
