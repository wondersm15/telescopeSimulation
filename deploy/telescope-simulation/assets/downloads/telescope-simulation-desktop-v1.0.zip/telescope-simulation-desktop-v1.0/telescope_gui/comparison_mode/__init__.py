"""Comparison mode tabs."""
