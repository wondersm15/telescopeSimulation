"""2D FFT-based PSF computation with pupil mask support.

Computes the Fraunhofer diffraction PSF as |FFT(pupil)|^2.  The pupil
mask can include a central obstruction and spider vanes, producing
realistic diffraction spikes in the PSF image.

When no spider vanes are present, the result matches the analytical
Airy/annular PSF (validated in tests via azimuthal average comparison).
"""

import numpy as np


def build_pupil_mask(grid_size: int, aperture_diameter: float,
                     obstruction_ratio: float = 0.0,
                     spider_vanes: int = 0,
                     spider_vane_width: float = 1.0) -> np.ndarray:
    """Build a 2D binary pupil mask.

    Args:
        grid_size: Number of pixels across the mask (square).
        aperture_diameter: Primary mirror diameter in mm.
        obstruction_ratio: Central obstruction ratio (0.0 to <1.0).
        spider_vanes: Number of spider vanes (0, 3, 4, 6 typical).
        spider_vane_width: Width of each vane in mm.

    Returns:
        2D float array (grid_size x grid_size), 1.0 = open, 0.0 = blocked.
    """
    # Coordinates in mm, centered on aperture
    radius = aperture_diameter / 2.0
    coords = np.linspace(-radius, radius, grid_size)
    xx, yy = np.meshgrid(coords, coords)
    rr = np.sqrt(xx ** 2 + yy ** 2)

    # Circular aperture
    mask = (rr <= radius).astype(float)

    # Central obstruction
    if obstruction_ratio > 0:
        obstruction_radius = radius * obstruction_ratio
        mask[rr <= obstruction_radius] = 0.0

    # Spider vanes: thin rectangles from center to edge, equally spaced.
    # Each vane is a HALF-strip (center → edge, one direction only), placed
    # at 2π/N intervals. For even N, anti-parallel pairs combine to form
    # crossing arms producing N diffraction spikes; for odd N, N arms produce
    # 2N spikes (each arm creates a spike pair perpendicular to itself).
    if spider_vanes > 0:
        vane_half_width = spider_vane_width / 2.0
        for k in range(spider_vanes):
            angle = 2.0 * k * np.pi / spider_vanes
            cos_a = np.cos(angle)
            sin_a = np.sin(angle)
            # Perpendicular distance from each pixel to the vane centre-line
            perp_dist = np.abs(-sin_a * xx + cos_a * yy)
            # Signed distance along the vane direction; keep only ≥ 0 so
            # each vane is a half-strip (arm from centre outward, not through)
            along_dist = cos_a * xx + sin_a * yy
            in_vane = ((perp_dist <= vane_half_width)
                       & (rr <= radius)
                       & (along_dist >= 0))
            mask[in_vane] = 0.0

    return mask


def compute_fft_psf(aperture_diameter: float, focal_length: float,
                    wavelength_mm: float, obstruction_ratio: float = 0.0,
                    spider_vanes: int = 0, spider_vane_width: float = 1.0,
                    grid_size: int = 1024,
                    oversample: int = 1,
                    return_raw_peak: bool = False):
    """Compute the 2D PSF via Fraunhofer diffraction (FFT of the pupil).

    PSF = |FFT(pupil)|^2, normalized so peak = 1.0.

    The pupil mask is built at *grid_size* resolution, then zero-padded
    to *grid_size * oversample* before FFT.  This increases image-plane
    sampling without changing the pupil sampling.

    The image-plane pixel pitch is:
        di = wavelength * focal_length / (fft_size * dp)
    where dp = aperture_diameter / grid_size, fft_size = grid_size * oversample.

    Args:
        aperture_diameter: Primary mirror diameter in mm.
        focal_length: Focal length in mm.
        wavelength_mm: Wavelength of light in mm.
        obstruction_ratio: Central obstruction ratio (0.0 to <1.0).
        spider_vanes: Number of spider vanes (0 = none).
        spider_vane_width: Width of each vane in mm.
        grid_size: Pupil mask resolution (power of 2 recommended).
        oversample: Zero-padding factor for finer image-plane sampling.
            Higher values give more pixels across the Airy disk.
            Default 1 (no padding).
        return_raw_peak: When True, also return the pre-normalisation peak
            intensity. For a binary pupil this is (open-pixel count)² — i.e.
            it scales with collected area² at fixed grid sampling. Two PSFs
            computed with the same grid_size/oversample/aperture are then
            directly comparable (their raw-peak ratio is the Strehl-type
            peak-intensity ratio, e.g. (1−ε²)² for a central obstruction).

    Returns:
        Tuple of (psf_2d, half_size_mm) — or, when return_raw_peak is True,
        (psf_2d, half_size_mm, raw_peak) where:
        - psf_2d: 2D array normalized to peak = 1.0
        - half_size_mm: half-width of the image in mm
        - raw_peak: pre-normalisation peak intensity (arbitrary but
          comparable across calls with identical sampling)
    """
    mask = build_pupil_mask(grid_size, aperture_diameter, obstruction_ratio,
                            spider_vanes, spider_vane_width)

    # Zero-pad for finer image-plane sampling
    fft_size = grid_size * oversample
    if oversample > 1:
        padded = np.zeros((fft_size, fft_size))
        offset = (fft_size - grid_size) // 2
        padded[offset:offset + grid_size, offset:offset + grid_size] = mask
        mask = padded

    # Compute the Fraunhofer diffraction pattern
    # PSF = |FFT(pupil)|^2
    field = np.fft.fftshift(np.fft.fft2(np.fft.ifftshift(mask)))
    psf = np.abs(field) ** 2

    # Normalize to peak = 1.0
    peak = psf.max()
    if peak > 0:
        psf = psf / peak

    # Image plane pixel pitch (dp stays based on original grid_size)
    dp = aperture_diameter / grid_size  # pupil plane pixel size (mm)
    di = wavelength_mm * focal_length / (fft_size * dp)  # image plane pixel size (mm)
    half_size_mm = (fft_size / 2.0) * di

    if return_raw_peak:
        return psf, half_size_mm, float(peak)
    return psf, half_size_mm
